Robert,
  This is a work in progress but it seems to produce OS agnostic code.
The issues that will probably arise is when bc9 Run Time Library code gets included.
You should download the bc9Adp2 package from SourceForge primarily for the help file at this juncture:
https://sourceforge.net/projects/bc9basic/files/bc9Adp2/bc9Adp2_9257_1007.zip/download

I have no experience in microcontroller coding but I can add or subtract items from bc9 based on your knowledge.

From a command prompt with bc9.exe, AStyle.exe and InserOPtArg.exe either in your path or in the same folder:
bc9 your_basic_code -gen
Note no extension. ".bas" is assumed.

If you want to use the ide copy bc9.exe and InsertOptArg.exe from this zip to the bc9Adp2 folder.
Fire Up bcEdit.
Go to Menu->Options->Build Options
You will be modifying one of these items for generic translating. It makes no difference which one you choose.
Select one, and in the pop up window, change the Menu item to Generic and the command to bc9 -gen
and click ok
This will be the one you choose for translations.

While you can code without a main function I prefer using one hence the $NOMAIN at the top of the source.
You will notice that Robert01.bas has a Sub main() while Robert02.bas has a Function. Note the difference in th "c" translations. With the function you have global variables to access the command count/line anywhere in your program.

As I mentioned in another email optional function arguments may pop up in bc9 RTL code. For that reason you should always run the InsertOptArg utility on the translated "c" code. See the examples.

You may need to use Raw instead of Dim for variables depending on your compiler.
Dim As Integer i translates to
  int i = {0};
Raw As Integer i translates to
  int      j;

Have fun.

James